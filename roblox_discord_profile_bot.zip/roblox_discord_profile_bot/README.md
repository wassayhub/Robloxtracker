# Roblox Discord Profile Bot

This bot provides `/profile <username>` and `/trackerinfo`.

It looks up public Roblox account information only. It does **not** track or reveal a person's
private live presence, current game, or last-seen time, and it does not use Roblox account cookies.

## Files
- `main.py` — bot code
- `requirements.txt` — Python dependencies

## Run locally
1. Install Python 3.11+.
2. Run `pip install -r requirements.txt`.
3. Set `DISCORD_TOKEN` as an environment variable.
4. Optional: set `GUILD_ID` to your Discord server ID for quicker slash-command updates.
5. Run `python main.py`.

Never commit your bot token or put it in source code.

## Deploy on Railway
1. Upload these files to a private GitHub repository.
2. In Railway, create a project and choose **Deploy from GitHub repo**.
3. Select the repository.
4. In the Railway service's **Variables** tab, add `DISCORD_TOKEN` with your bot token.
5. Optionally add `GUILD_ID` with your Discord server ID.
6. Set the start command to `python main.py` if Railway does not detect it.
7. Deploy and inspect the logs for `Logged in as ...`.

In the Discord Developer Portal, enable the `bot` and `applications.commands` installation
scopes and invite the bot to your server with permission to send messages and embed links.
Do not enable privileged intents; this bot does not need them.

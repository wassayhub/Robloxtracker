import os
import aiohttp
import discord
from discord import app_commands
from discord.ext import commands

TOKEN = os.environ["DISCORD_TOKEN"]
GUILD_ID = os.getenv("GUILD_ID")  # Optional: speeds up slash-command updates in one server.

intents = discord.Intents.default()
bot = commands.Bot(command_prefix="!", intents=intents)

async def lookup_roblox_user(username: str):
    url = "https://users.roblox.com/v1/usernames/users"
    payload = {"usernames": [username], "excludeBannedUsers": True}
    timeout = aiohttp.ClientTimeout(total=15)
    async with aiohttp.ClientSession(timeout=timeout) as session:
        async with session.post(url, json=payload) as response:
            response.raise_for_status()
            data = await response.json()
    users = data.get("data", [])
    return users[0] if users else None

@bot.event
async def on_ready():
    try:
        if GUILD_ID:
            guild = discord.Object(id=int(GUILD_ID))
            bot.tree.copy_global_to(guild=guild)
            synced = await bot.tree.sync(guild=guild)
            print(f"Synced {len(synced)} command(s) to guild {GUILD_ID}")
        else:
            synced = await bot.tree.sync()
            print(f"Synced {len(synced)} global command(s)")
    except Exception as exc:
        print(f"Slash-command sync failed: {exc}")
    print(f"Logged in as {bot.user}")

@bot.tree.command(name="profile", description="Find a public Roblox profile by username")
@app_commands.describe(username="Roblox username, e.g. mohsinxcheats")
async def profile(interaction: discord.Interaction, username: str):
    await interaction.response.defer(thinking=True)
    try:
        user = await lookup_roblox_user(username.strip())
    except Exception:
        await interaction.followup.send(
            "I couldn't reach Roblox right now. Please try again later.",
            ephemeral=True
        )
        return

    if not user:
        await interaction.followup.send(
            f"No public Roblox account was found for **{discord.utils.escape_markdown(username)}**."
        )
        return

    user_id = user["id"]
    display_name = user.get("displayName") or user["name"]
    profile_url = f"https://www.roblox.com/users/{user_id}/profile"

    embed = discord.Embed(
        title=display_name,
        url=profile_url,
        description=f"**Username:** `{user['name']}`\n**User ID:** `{user_id}`"
    )
    embed.add_field(
        name="Activity",
        value="Live online status and current game aren't reliably available through this public lookup.",
        inline=False
    )
    embed.add_field(name="Profile", value=f"[Open Roblox profile]({profile_url})", inline=False)
    await interaction.followup.send(embed=embed)

@bot.tree.command(name="trackerinfo", description="Explain what this Roblox bot can and cannot track")
async def trackerinfo(interaction: discord.Interaction):
    await interaction.response.send_message(
        "I can look up public Roblox profile information. I cannot bypass privacy settings "
        "or guarantee another user's live online status, current game, or last-seen time."
    )

bot.run(TOKEN)
